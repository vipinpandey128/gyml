﻿namespace WebGYM.ViewModels
{
    public class YearWiseRequestModel
    {
        // ReSharper disable once InconsistentNaming
        public string YearID { get; set; }
    }
}