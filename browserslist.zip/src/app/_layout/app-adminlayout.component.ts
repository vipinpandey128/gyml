import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-app-layout',
  templateUrl: './app-admin-layout.component.html',
  styleUrls: [
    ]
})
export class AppAdminLayoutComponent implements OnInit 
{

 
  constructor() { }

  ngOnInit() {
  
  }

}