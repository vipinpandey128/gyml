export class ResponseMemberModel {
    public MemberName: string;
    public MemberNo: string;
}