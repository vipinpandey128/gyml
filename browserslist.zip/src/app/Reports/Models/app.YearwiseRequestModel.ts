export class YearwiseRequestModel
{
    public YearID :string;
}