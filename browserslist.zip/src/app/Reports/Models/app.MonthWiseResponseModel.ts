export class MonthWiseResponseModel 
{
    public MemberFName: string
    public MemberNo: string
    public MemberLName: string
    public MemberMName: string
    public CreateDate: string
    public Total: number
    public Paymentmonth: string
    public PaymentAmount: number
    public Username: string
}