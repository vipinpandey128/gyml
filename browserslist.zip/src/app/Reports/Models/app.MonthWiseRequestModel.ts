export class MonthWiseRequestModel
{
    public MonthId :string;
}