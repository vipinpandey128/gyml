export class SchemeMasterModel {
    public SchemeID: number = 0;
    public SchemeName: string = "";
    public Status: boolean = false;
}