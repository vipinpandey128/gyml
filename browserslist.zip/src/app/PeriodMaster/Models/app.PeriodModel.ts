export class PeriodModel 
{
    public PeriodID: number = 0;
    public Text: string = "";
    public Value: string = "";
}