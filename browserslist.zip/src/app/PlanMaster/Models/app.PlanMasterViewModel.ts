export class PlanMasterViewModel {

    public PlanID: number;
    public PlanName: string;
    public PlanAmount: number;
    public ServicetaxAmount: string;
    public ServiceTax: string;
    public RecStatus: boolean;
    public SchemeID: number;
    public SchemeName: string;
    public PeriodID: number;
    public Text: string;
    public TotalAmount: number;
    public ServicetaxNo: string;
}