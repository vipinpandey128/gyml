export const environment = {
  production: true,
    apiEndpoint: 'http://api.webscrackers.com'
};
